# -*- coding: utf-8 -*-

{
    "name": "Package Transfer Details",
    'author': "Reliution",
    'website': "",
    'license': 'OPL-1',
    'version': '17.0.0.2',
    "support": "",
    "category": "",
    "summary": "",
    "description": """""",
    "depends": ['sale', 'stock','res_area'],
    "data": [
        'security/ir.model.access.csv',
        'views/transfer_details_view.xml',
        'views/split_package_wizard.xml'
    ],
    'installable': True,
    'assets': {},
    'auto_install': False,
    'application': True,
    'sequence': 0
}
