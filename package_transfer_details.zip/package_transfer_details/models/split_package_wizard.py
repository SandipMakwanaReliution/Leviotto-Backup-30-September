# -*- coding: utf-8 -*-
from odoo import models, fields, _
from odoo.exceptions import ValidationError


class PackageSplitWizard(models.TransientModel):
    _name = 'package.split.wizard'
    _description = 'Package Split Wizard'

    package_id = fields.Many2one('stock.quant.package', string="Package")
    product_tmpl_id = fields.Many2one('product.template', string='Product')
    package_lines = fields.One2many('package.split.wizard.line', 'wizard_id')
    transfer_id = fields.Many2one("package.transfer.details", string="Transfer")

    def create_splited_line_package(self):
        stock_quant_obj = self.env['stock.quant']
        new_package = self.env['stock.quant.package'].create({
            'name': 'SPTP-' + self.package_id.name,
            'is_transfer_package': True
        })
        for line in self.package_lines:
            quant_id = stock_quant_obj.search([
                ('package_id', '=', self.package_id.id),
                ('product_id', '=', line.product_id.id),
            ], limit=1)
            if not quant_id:
                raise ValidationError(f"No stock available for product {line.product_id.display_name}")
            if quant_id.quantity < line.quantity:
                raise ValidationError(f"Added ({line.quantity}) Quantity is not available in {line.product_id.display_name}.")

            stock_quant_obj.create({
                'product_id': line.product_id.id,
                'location_id': quant_id.location_id.id,
                'package_id': new_package.id,
                'quantity': line.quantity,
                'product_uom_id': quant_id.product_uom_id.id,
            })
            quant_id.quantity -= line.quantity
        existing_transfer = self.transfer_id.package_transfer.filtered(lambda p: p.package_id == self.package_id)
        if self.transfer_id and existing_transfer:
            existing_transfer.update({
                'product_id': self.product_tmpl_id.id,
                'package_id': new_package.id,
                'quantity': sum(new_package.quant_ids.mapped('quantity')),
            })
        else:
            self.transfer_id.package_transfer.create({
                'product_id': self.product_tmpl_id.id,
                'package_id': new_package.id,
                'quantity': sum(new_package.quant_ids.mapped('quantity')),
                'state': 'draft'
            })
        if self.transfer_id:
            self.transfer_id.update({
                'split_package_char': '',
                'split_package_id': False
            })

        self.env.cr.commit()

        return {'type': 'ir.actions.act_window_close'}

    def default_get(self, fields):
        res = super(PackageSplitWizard, self).default_get(fields)
        package_id = self.env.context.get('default_package_id')
        transfer_id = self.env.context.get('default_transfer_id')
        if package_id and transfer_id:
            package = self.env['stock.quant.package'].browse(package_id)
            transfer = self.env['package.transfer.details'].browse(transfer_id)
            package_lines = []
            for line in transfer.order_lines:
                quant = package.quant_ids.filtered(lambda q: q.product_id == line.product_id)
                remaining_qty = line.move_ids.product_uom_qty - line.move_ids.quantity
                if remaining_qty >= quant.quantity:
                    quantity = quant.quantity
                else:
                    quantity = remaining_qty

                if quant and quantity > 0:
                    package_lines.append((0, 0, {
                        'product_id': quant.product_id.id,
                        'quantity': quantity,
                        'product_uom_id': quant.product_uom_id.id,
                    }))
                res['package_lines'] = package_lines
        return res


class PackageSplitWizardLine(models.TransientModel):
    _name = 'package.split.wizard.line'
    _description = 'Package Split Wizard Line'

    wizard_id = fields.Many2one('package.split.wizard', string="Wizard")
    product_id = fields.Many2one('product.product', string="Product", required=True)
    quantity = fields.Float(string="Quantity", required=True)
    product_uom_id = fields.Many2one('uom.uom', string="Unit of Measure")
