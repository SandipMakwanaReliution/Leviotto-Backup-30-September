# -*- coding: utf-8 -*-

from odoo import models, _, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()

        for order in self:
            if not order.is_return_order and not order.is_supermarket_sale:
                for line in order.order_line:
                    product_template = line.product_template_id
                    package_qty = line.package_qty
                    package_id = line.package_id

                    if package_id:
                        template_unique_packages = {}
                        if package_id.id not in template_unique_packages:
                            template_unique_packages[package_id.id] = {}

                        if product_template.id not in template_unique_packages[package_id.id]:
                            template_unique_packages[package_id.id][product_template.id] = set()

                        if package_qty:
                            template_unique_packages[package_id.id][product_template.id].add(package_qty)

                        for package_ids, template_id in template_unique_packages.items():
                            total_package_qty = sum(sum(qty_set) for qty_set in template_id.values())
                            transfer_details_id = self.env['package.transfer.details'].create({
                                'name': order.name,
                                'product_tmpl_id': next(iter(template_id)),
                                'partner_id': order.partner_id.id,
                                'area': order.area.id,
                                'date_order': order.date_order,
                                'package_count': total_package_qty,
                                'so_id': order.id,
                                'state': 'draft'
                            })
                            order_lines = self.order_line.filtered(lambda l: l.package_id.id == package_ids)
                            order_lines.write({
                                'package_transfer_detail_id': transfer_details_id.id
                            })
                    else:
                        transfer_details_id = self.env['package.transfer.details'].create({
                            'name': order.name,
                            'product_tmpl_id': product_template.id,
                            'partner_id': order.partner_id.id,
                            'area': order.area.id,
                            'date_order': order.date_order,
                            'so_id': order.id,
                            'state': 'draft'
                        })
                        line.package_transfer_detail_id = transfer_details_id.id

        return res


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    package_transfer_detail_id = fields.Many2one('package.transfer.details')
    product_variant_value_ids = fields.Many2one('product.template.attribute.value', compute='_compute_product_variant_value_ids')
    move_qty = fields.Float(related='move_ids.quantity')

    @api.depends('product_id', 'product_template_id')
    def _compute_product_variant_value_ids(self):
        for rec in self:
            if rec.product_id and rec.product_id.product_template_variant_value_ids:
                for variant_value_id in rec.product_id.product_template_variant_value_ids:
                    rec.product_variant_value_ids = variant_value_id
            else:
                rec.product_variant_value_ids = False
