# -*- coding: utf-8 -*-
from odoo import models, fields, _


class StockQuantPackage(models.Model):
    _inherit = 'stock.quant.package'

    total_package_quantity = fields.Float('Total Package Quantity')
    is_transfer_package = fields.Boolean("Is Transfer package")