# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class TransferDetails(models.Model):
    _name = 'package.transfer.details'
    _description = 'Transfer Details'
    _order = 'so_id asc'

    name = fields.Char(string='Reference')
    so_id = fields.Many2one('sale.order','Sale Order')
    product_tmpl_id = fields.Many2one('product.template', string='Product')
    partner_id = fields.Many2one('res.partner', string="Customer")
    area = fields.Many2one('res.area', related='partner_id.area', store=True)
    date_order = fields.Datetime(string='Order Date', default=fields.Datetime.now)
    package_count = fields.Integer(string='Package Count', default=0)
    package_transfer = fields.One2many(
        'stock.package.transfer', 'transfer_id', 'Package Transfer'
    )
    order_lines = fields.One2many('sale.order.line', 'package_transfer_detail_id')
    state = fields.Selection([
        ('draft', 'New'),
        ('done', 'Done')], string='Status', copy=False, compute='_compute_state', store=True)
    package_id = fields.Many2one(
        'stock.quant.package',
        string="Select Package"
    )
    product_package_ids = fields.One2many('stock.quant.package', compute='_compute_product_package_ids')
    scan_package_char = fields.Char('Scan Package(Text)')
    split_package_id = fields.Many2one(
        'stock.quant.package',
        string="Split Package",
    )
    split_package_ids = fields.Many2many(
        'stock.quant.package',
        string="Split Package", compute='_compute_split_package_ids'
    )
    split_package_char = fields.Char('Split Package(Text)')

    def _compute_split_package_ids(self):
        stock_location = self.env['stock.location'].search([
            ('location_id', 'child_of', self.env.ref('stock.stock_location_stock').id)
        ])
        for rec in self:
            rec.split_package_ids = rec.product_tmpl_id.product_variant_ids.stock_quant_ids.filtered(
                lambda quant_id: quant_id.location_id.usage == 'internal' and
                                 quant_id.location_id != self.env.ref('stock.stock_location_company') and
                                 quant_id.location_id in stock_location
            ).mapped('package_id').ids

    def _compute_product_package_ids(self):
        stock_location = self.env['stock.location'].search([
            ('location_id', 'child_of', self.env.ref('stock.stock_location_stock').id)
        ])
        for rec in self:
            rec.product_package_ids = rec.product_tmpl_id.product_variant_ids.stock_quant_ids.filtered(
                lambda quant_id: quant_id.location_id.usage == 'internal' and
                                 quant_id.location_id != self.env.ref('stock.stock_location_company') and
                                 quant_id.location_id in stock_location
            ).mapped('package_id')
            for rec in rec.product_package_ids:
                rec.total_package_quantity = sum(rec.quant_ids.mapped('quantity'))

    @api.onchange('package_id', 'scan_package_char')
    def onchange_select_package(self):
        if self.package_id or self.scan_package_char:
            # Add the whole package as a single line
            select_package_id = []
            if self.package_id:
                select_package_id = self.env['stock.quant.package'].search([('id', '=', self.package_id.id)], limit=1)
            if self.scan_package_char:
                select_package_id = self.env['stock.quant.package'].search([('name', '=', self.scan_package_char)], limit=1)
            transfer = self.env['stock.package.transfer'].search(
                [('package_id', '=', select_package_id.id), ('state', '=', 'draft')])
            if transfer:
                raise ValidationError(
                    "This Package has already been reserved in another transfer. Please either update that transfer with this Package or try another Package.")

            self.package_transfer.create({
                'transfer_id': self._origin.id,
                'product_id': self.product_tmpl_id.id,
                'package_id': select_package_id.id,
                'quantity': select_package_id.total_package_quantity,
                'state': 'draft'
            })
            self.env.cr.commit()
            self.write({
                'package_id': ''
            })
            if self.product_package_ids:
                self.split_package_ids = self.product_package_ids._origin.filtered(
                    lambda p: p.id not in self.package_transfer.package_id.ids
                )

    def split_package_wizard(self):
        # if not self.split_package_id:
        #     raise ValidationError(_('Please select the Package.'))
        if self.split_package_char:
            split_package = self.env['stock.quant.package'].search([('name', '=', self.split_package_char)], limit=1).id
        else:
            split_package = self.split_package_id.id
        return {
            'name': 'Split Package Wizard',
            'type': 'ir.actions.act_window',
            'res_model': 'package.split.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('package_transfer_details.package_split_wizard_form_view').id,
            'context': {
                'default_product_tmpl_id': self.product_tmpl_id.id,
                'default_package_id': split_package,
                'default_transfer_id': self.id,
            },
            'target': 'new',
        }

    @api.onchange('split_package_id')
    def onchange_split_package_id(self):
        if self.split_package_id:
            package_transfer = self.package_transfer
            if package_transfer:
                for transfer in package_transfer:
                    if transfer and transfer.state == 'draft':
                        raise ValidationError(
                            "You cannot split another package. The transfer of one package is already in draft state. Please update that first.")

    @api.depends('order_lines', 'order_lines.move_qty', 'order_lines.product_uom_qty')
    def _compute_state(self):
        for rec in self:
            if rec.order_lines:
                if all(line.product_uom_qty == line.move_qty for line in rec.order_lines):
                    rec.write({
                        'state': 'done'
                    })
                else:
                    rec.write({
                        'state': 'draft'
                    })

class StockPackageTransfer(models.Model):
    _name = 'stock.package.transfer'
    _description = 'Stock Package Transfer'

    transfer_id = fields.Many2one('package.transfer.details', string="Transfer Reference")
    product_id = fields.Many2one('product.template', string="Product")
    quantity = fields.Float(string="Quantity")
    package_id = fields.Many2one('stock.quant.package', "Package")
    state = fields.Selection([
        ('draft', 'New'),
        ('done', 'Done')], string='Status', copy=False)

    def update_packages_from_stock_to_output(self):
        for rec in self:
            if not rec:
                raise ValidationError(_("Please add package transfer lines."))

            if rec.quantity <= 0:
                raise ValidationError(_("Quantity must be greater than zero."))

            if not rec.package_id.total_package_quantity <= rec.quantity:
                raise ValidationError(_("Not enough quantity in the selected package."))

            picking = self.env['stock.picking'].create({
                'picking_type_id': self.package_id.location_id.warehouse_id.id,
                'location_id': rec.package_id.location_id.id,
                'location_dest_id': rec.env.ref('stock.stock_location_output').id,
                'state': 'draft',
            })
            self.env['stock.package_level'].create({
                'picking_id': picking.id,
                'package_id': rec.package_id.id,
                'location_id': rec.package_id.location_id.id,
                'location_dest_id': rec.env.ref('stock.stock_location_output').id,
                'company_id': rec.package_id.location_id.company_id.id,
            })
            self.env.cr.commit()
            # picking.action_confirm()

            sale_line_id = self.env['sale.order.line']
            for sale_line_ids in rec.transfer_id.order_lines:
                sale_line_id = sale_line_ids
            move_id = self.env['stock.move']
            for move_ids in sale_line_id.move_ids:
                move_id = move_ids
            demand_qty = move_id.product_uom_qty
            total_qty = sum(move_line.quantity for move_line in move_id.move_line_ids)
            rest_qty = demand_qty - total_qty
            if rec.quantity <= rest_qty:
                self.env['stock.move.line'].create({
                    'move_id': move_id.id,
                    'product_id': move_id.product_id.id,
                    'product_uom_id': move_id.product_uom.id,
                    'location_id': move_id.location_id.id,
                    'location_dest_id': move_id.location_dest_id.id,
                    'quantity': rec.quantity,
                    'package_id': rec.package_id.id,
                    'result_package_id': rec.package_id.id,
                    })
            elif rec.quantity > rest_qty:
                self.env['stock.move.line'].create({
                    'move_id': move_id.id,
                    'product_id': move_id.product_id.id,
                    'product_uom_id': move_id.product_uom.id,
                    'location_id': move_id.location_id.id,
                    'location_dest_id': move_id.location_dest_id.id,
                    'quantity': rest_qty,
                    'package_id': rec.package_id.id,
                    'result_package_id': rec.package_id.id,
                    })

            picking.button_validate()

            rec.state = 'done'

            picking_ids = rec.transfer_id.so_id.picking_ids
            for picking_id in picking_ids:
                if picking_id:
                    picking_id.action_assign()
            if all(move.product_uom_qty == move.quantity for move in rec.transfer_id.order_lines.move_ids):
                rec.transfer_id.write({
                    'state': 'done'
                })
