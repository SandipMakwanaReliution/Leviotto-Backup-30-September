# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AccountMove(models.Model):
    _inherit = 'account.move'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', compute='_compute_shop_id', store=True)
    is_shared_expense = fields.Boolean(default=False, string='Is Shared Expense', compute='_compute_shop_id', store=True)

    @api.depends('invoice_line_ids.sale_line_ids.order_id.shop_id', 'payment_id')
    def _compute_shop_id(self):
        for move in self:
            shop = self.line_ids.sale_line_ids.order_id.shop_id
            if not move.payment_id and shop:
                move.shop_id = shop
            elif move.payment_id:
                move.shop_id = move.payment_id.shop_id
                move.is_shared_expense = move.payment_id.is_shared_expense
            else:
                move.shop_id = False


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='move_id.shop_id', store=True)
    is_shared_expense = fields.Boolean(default=False, string='Is Shared Expense', related='move_id.is_shared_expense', store=True)
