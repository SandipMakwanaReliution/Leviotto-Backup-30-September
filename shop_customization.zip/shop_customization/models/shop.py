# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class ShopShop(models.Model):
    _name = 'shop.shop'

    name = fields.Char(string='Shop Name')
    responsible_user_id = fields.Many2one(comodel_name='res.users', string='Responsible User')
    linked_user_ids = fields.One2many(comodel_name='res.users', inverse_name='shop_id', string='Linked Users')
    shop_location_id = fields.Many2one(comodel_name='stock.location')

    @api.onchange('responsible_user_id')
    def _onchange_responsible_user(self):
        if self.responsible_user_id:
            if not self.responsible_user_id.shop_id:
                raise ValidationError(_("You must assign a shop before marking a user as responsible."))
            if self.responsible_user_id.is_responsible:
                raise ValidationError(_("The shop already has a responsible user assigned"))
            self.responsible_user_id.is_responsible = True
        else:
            if self._origin and self._origin.responsible_user_id:
                self._origin.responsible_user_id.is_responsible = False

