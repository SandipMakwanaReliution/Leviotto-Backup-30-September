# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class ResUsers(models.Model):
    _inherit = 'res.users'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop')
    is_responsible = fields.Boolean(default=False, string='Is Responsible')

    @api.onchange('is_responsible', 'shop_id')
    def _onchange_responsible_or_shop(self):
        if self.is_responsible:
            if not self.shop_id:
                raise ValidationError(_("You must assign a shop before marking a user as responsible."))

            if self.shop_id.responsible_user_id:
                raise ValidationError(_("The shop already has a responsible user assigned"))

            self.shop_id.responsible_user_id = self.ids[0]

        if not self.is_responsible and self.shop_id:
            self.shop_id.responsible_user_id = False
