# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class StockMove(models.Model):
    _inherit = 'stock.move'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='picking_id.shop_id', store=True)
