# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', default=lambda self: self.env.user.shop_id)
    is_supermarket_sale = fields.Boolean(string='Is Supermarket Sale', default=False)

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        for order in self:
            order_line_packages = {}
            for line in order.order_line:
                if line.package_id and line.product_id:
                    for rec in line.package_id.quant_ids:
                        if rec.product_id == line.product_id and rec.quantity < line.product_uom_qty:
                            raise ValidationError(f"Package {line.package_id.name} does not have enough quantity available.")

                    order_line_packages[line.id] = line.package_id

            if order.is_supermarket_sale and order.picking_ids:
                for picking in order.picking_ids:
                    if not picking.state == 'cancel':
                        picking.location_id = picking.shop_id.shop_location_id
                        picking.action_assign()

                        for move in picking.move_ids_without_package:
                            sale_line = move.sale_line_id.id
                            for move_line in move.move_line_ids:
                                if sale_line and sale_line in order_line_packages:
                                    move_line.package_id = order_line_packages[sale_line].id

        return res


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='order_id.shop_id', store=True)
