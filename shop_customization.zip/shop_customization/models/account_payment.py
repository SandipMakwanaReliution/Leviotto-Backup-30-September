# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AccountMove(models.Model):
    _inherit = 'account.payment'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='expense_sheet_id.shop_id', store=True)
    is_shared_expense = fields.Boolean(default=False, string='Is Shared Expense', related='expense_sheet_id.is_shared_expense', store=True)
