# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop')