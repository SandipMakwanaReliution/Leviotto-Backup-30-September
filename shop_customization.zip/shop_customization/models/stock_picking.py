# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _inherit = 'stock.picking'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='sale_id.shop_id', store=True)
