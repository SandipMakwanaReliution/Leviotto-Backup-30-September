# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class HrExpense(models.Model):
    _inherit = 'hr.expense'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', related='sheet_id.shop_id', store=True)
    is_shared_expense = fields.Boolean(default=False, string='Is Shared Expense', related='sheet_id.is_shared_expense', store=True)

class HrExpenseSheet(models.Model):
    _inherit = 'hr.expense.sheet'

    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop', default=lambda self: self.env.user.shop_id)
    is_shared_expense = fields.Boolean(default=False, string='Is Shared Expense')