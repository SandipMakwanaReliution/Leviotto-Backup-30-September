# -*- coding: utf-8 -*-

{
    'name': 'Shop Customization',
    'version': '17.0.0.1.0',
    'license': 'LGPL-3',
    'description': """
    """,
    'depends': [
        'base',
        'sale',
        'stock',
        'account',
        'hr_expense',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/shop_view.xml',
        'views/res_users.xml',
        'views/sale_order_view.xml',
        'views/stock_picking_view.xml',
        'views/account_move.xml',
        'views/account_journal.xml',
        'views/hr_expense_view.xml',
        'views/account_payment.xml',
        'wizard/supermarket_sales_wizard.xml',
    ],
    'sequence': 0,
    'installable': True,
    'auto_install': False,
    'application': True,
}
