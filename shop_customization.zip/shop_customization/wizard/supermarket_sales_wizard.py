# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import tempfile
import base64
import pandas as pd


class SupermarketSalesWizard(models.TransientModel):
    _name = 'supermarket.sales.wizard'
    _description = 'Supermarket Sales Wizard'

    partner_id = fields.Many2one(comodel_name='res.partner', string='Customer', required=True)
    supermarket_id = fields.Many2one(comodel_name='shop.shop', string='Supermarket', required=True)
    barcode_file = fields.Binary(string='Upload File')
    header = fields.Html(string="header", readonly=True)

    def read_file(self):
        try:
            fp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
            fp.write(base64.decodebytes(self.barcode_file))
            fp.seek(0)

            df = pd.read_excel(fp.name, engine='openpyxl')
            if df.empty or df.shape[0] <= 0:
                raise ValidationError("File doesn't contain lines.")

            required_columns = ['product', 'qty', 'package']
            for column in required_columns:
                if column not in df.columns:
                    raise ValidationError(f"Column '{column}' missing in the Excel file.")

            product_lines = []
            missing_products = ''
            missing_package_product = []
            missing_package = ''

            if self.supermarket_id.shop_location_id:
                supermarket_location = self.supermarket_id.shop_location_id
            else:
                raise ValidationError(f"Supermarket '{self.supermarket_id.name}' does not have a location set.")

            for row_no, row in df.iterrows():
                row_data = row.to_dict()

                internal_ref = row_data.get('product')
                qty = row_data.get('qty')
                package_ref = row_data.get('package')

                if pd.isna(internal_ref):
                    raise ValidationError(f"Please enter a Product at row {row_no + 2}.")
                if pd.isna(qty):
                    raise ValidationError(f"Please enter a Qty at row {row_no + 2}.")
                if pd.isna(package_ref):
                    raise ValidationError(f"Please enter a Package at row {row_no + 2}.")

                if not isinstance(qty, (int, float)):
                    raise ValidationError(f"Invalid Qty '{qty}' at row {row_no + 2}. Please enter a valid qty.")
                if qty <= 0:
                    raise ValidationError(f"Qty must be positive at row {row_no + 2}.")

                product = self.env['product.product'].search([('default_code', '=', internal_ref)], limit=1)

                if product:
                    price = product.lst_price if product.lst_price else 0.0
                else:
                    missing_products += f'{internal_ref}, '
                    continue

                package_find = self.env['stock.quant.package'].search([
                    ('name', '=', package_ref),
                    ('location_id', '=', supermarket_location.id)], limit=1)
                package = self.env['stock.quant.package']
                if package_find:
                    if package_find.quant_ids and product:
                        for rec in package_find.quant_ids:
                            if rec.product_id == product and rec.quantity >= qty:
                                package = package_find
                            else:
                                missing_package_product.append({'package': package_find.name , 'product': product.default_code})
                else:
                    missing_package += f'{package_ref}, '
                    continue

                product_lines.append({
                    'product': product,
                    'qty': qty,
                    'price': price,
                    'package_id': package,
                })

            fp.close()

            if missing_products:
                raise ValidationError(f"Product Internal Reference {missing_products} were not found.")
            if missing_package_product:
                details = [f"Package '{item['package']}' does not contain product internal ref '{item['product']}' or not available qty"
                           for item in missing_package_product]
                raise ValidationError("\n".join(details))
            if missing_package:
                raise ValidationError(
                    f"Package {missing_package} is invalid or not available at the {supermarket_location.name} location.")

            supermarket_order = self.env['sale.order'].create({
                'partner_id': self.partner_id.id,
                'shop_id': self.supermarket_id.id,
                'is_supermarket_sale': True,
            })

            for line in product_lines:
                self.env['sale.order.line'].create({
                    'product_id': line['product'].id,
                    'name': line['product'].name,
                    'product_uom_qty': line['qty'],
                    'order_id': supermarket_order.id,
                    'price_unit': line['price'],
                    'package_id': line['package_id'].id,
                })

            return {
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'sale.order',
                'view_ids': self.env.ref('sale.view_order_form').id,
                'target': 'current',
                'res_id': supermarket_order.id
            }

        except Exception as e:
            raise ValidationError(e)

    @api.model
    def default_get(self, fields):
        rec = super(SupermarketSalesWizard, self).default_get(fields)
        header = """<div>
                        <b>The header of the file should be like this - </b>
                        <table class="table table-bordered text-center">
                            <tr>
                                <td>product</td>
                                <td>qty</td>
                                <td>package</td>
                            </tr>
                        </table>
                    </div>"""
        rec.update(header=header)
        return rec