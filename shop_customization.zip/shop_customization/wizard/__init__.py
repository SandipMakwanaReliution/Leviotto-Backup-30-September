# -*- coding: utf-8 -*-

from . import supermarket_sales_wizard

