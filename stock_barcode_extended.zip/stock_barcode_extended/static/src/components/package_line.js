/** @odoo-module **/

import PackageLine from '@stock_barcode/components/package_line';
import { patch } from "@web/core/utils/patch";

patch(PackageLine.prototype, {

    setPackageQty(pacakgeBarcode) {
    debugger;
        if (pacakgeBarcode) {
            this.env.model.processBarcode(pacakgeBarcode);
        }
    }

});