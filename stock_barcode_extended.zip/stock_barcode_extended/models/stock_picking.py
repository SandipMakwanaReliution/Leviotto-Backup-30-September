# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    def get_picking_stock_to_supermarket_action_picking_type(self):
        picking_type_id = self.env.ref('stock_barcode_extended.picking_type_stock_to_supermarket')
        action = picking_type_id._get_action('stock_barcode.stock_picking_action_kanban')
        action['context'].update({
            'active_model': 'stock.picking.type',
            'active_id': picking_type_id.id
        })
        return action
