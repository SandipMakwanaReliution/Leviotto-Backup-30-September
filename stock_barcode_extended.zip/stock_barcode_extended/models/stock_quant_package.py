# -*- coding: utf-8 -*-

from odoo import models, api, fields


class QuantPackage(models.Model):
    _inherit = 'stock.quant.package'

    product_name = fields.Char(compute='_compute_product_tmpl_name')
    # name = fields.Char(compute='_compute_name')

    def _compute_product_tmpl_name(self):
        for rec in self:
            product_name = ''
            if rec.quant_ids:
                product_tmpl_id = rec.quant_ids.mapped('product_id.product_tmpl_id')
                if product_tmpl_id:
                    product_name = product_tmpl_id.name
            rec.product_name = product_name

    @api.model
    def _get_fields_stock_barcode(self):
        return ['name', 'location_id', 'package_type_id', 'quant_ids', 'product_name']


    # @api.depends('package_type_id')
    # def _compute_name(self):
    #     for rec in self:
    #         rec.name = rec.name