# -*- encoding: utf-8 -*-

{
    "name": "Stock Barcode extended",
    "version": "17.0.0.1",
    "depends": ["base", "stock_barcode"],
    'author': "Reliution",
    "category": "",
    "description": """""",
    'license': 'LGPL-3',
    "data": [
        'views/menu_view.xml',
        'data/data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'stock_barcode_extended/static/src/**/*.js',
            'stock_barcode_extended/static/src/**/*.xml',
        ],
    },
    'application': True,
    'installable': True,
    'auto_install': False,
}
