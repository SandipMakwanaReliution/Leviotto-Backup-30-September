# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.http import request, route, Controller


class ProductPackageController(Controller):

    @route('/product/package/order_lines_info', auth='user', type='json')
    def product_package_get_order_lines_info(self, res_model, order_id, package_ids, **kwargs):
        order = request.env[res_model].browse(order_id)
        return order.with_company(order.company_id)._get_product_package_order_line_info(
            package_ids, **kwargs,
        )

    @route('/product/package/update_order_line_info', auth='user', type='json')
    def product_package_update_order_line_info(self, res_model, order_id, package_id, quantity=0, **kwargs):
        order = request.env[res_model].browse(order_id)
        return order.with_company(order.company_id)._update_package_order_line_info(
            package_id, quantity, **kwargs,
        )
