# -*- coding: utf-8 -*-

{
    "name": "Package Catalogue",
    'author': "Reliution",
    'website': "",
    'license': 'OPL-1',
    'version': '17.0.0.2',
    "support": "",
    "category": "",
    "summary": "",
    "description": """""",
    "depends": ['sale', 'base', 'uom', 'stock'],
    "data": [
        'security/ir.model.access.csv',
        'views/sale_order_views.xml',
        'views/stock_quant_views.xml'
    ],
    'installable': True,
    'assets': {
        'web.assets_backend': [
            'package_catalogue/static/src/product_package/**/*',
        ],
    },
    'auto_install': False,
    'application': True,
    'sequence': 0
}
