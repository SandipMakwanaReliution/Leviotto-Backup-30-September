/** @odoo-module **/

import { KanbanRenderer } from "@web/views/kanban/kanban_renderer";
import { useService } from "@web/core/utils/hooks";

import { ProductPackageKanbanRecord } from "./kanban_record";

export class ProductPackageKanbanRenderer extends KanbanRenderer {
    static template = "ProductPackageKanbanRenderer";
    static components = {
        ...KanbanRenderer.components,
        KanbanRecord: ProductPackageKanbanRecord,
    };
    setup() {
        super.setup();
        this.action = useService("action");
    }

}
