/** @odoo-module */

import { Record } from "@web/model/relational_model/record";
import { RelationalModel } from "@web/model/relational_model/relational_model";

class ProductPackageRecord extends Record {
    setup(config, data, options = {}) {
        this.productPackageData = data.productPackageData;
        data = { ...data };
        delete data.productPackageData;
        super.setup(config, data, options);
    }
}

export class ProductPackageKanbanModel extends RelationalModel {
    static Record = ProductPackageRecord;
    async _loadData(params) {
        const result = await super._loadData(...arguments);
        if (!params.isMonoRecord && !params.groupBy.length) {
            const orderLinesInfo = await this.rpc("/product/package/order_lines_info", {
                order_id: params.context.order_id,
                package_ids: result.records.map((rec) => rec.id),
                res_model: params.context.product_package_order_model,
            });
            for (const record of result.records) {
                record.productPackageData = orderLinesInfo[record.id];
            }
        }
        return result;
    }
}
