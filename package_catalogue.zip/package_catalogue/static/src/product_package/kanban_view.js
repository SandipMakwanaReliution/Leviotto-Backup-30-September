/** @odoo-module **/

import { kanbanView } from "@web/views/kanban/kanban_view";
import { registry } from "@web/core/registry";

import { ProductPackageKanbanController } from "./kanban_controller";
import { ProductPackageKanbanModel } from "./kanban_model";
import { ProductPackageKanbanRenderer } from "./kanban_renderer";
import { ProductPackageSearchPanel} from "./search/search_panel";

export const productPackageKanbanView = {
    ...kanbanView,
    Controller: ProductPackageKanbanController,
    Model: ProductPackageKanbanModel,
    Renderer: ProductPackageKanbanRenderer,
    SearchPanel: ProductPackageSearchPanel,
};

registry.category("views").add("product_kanban_package", productPackageKanbanView);
