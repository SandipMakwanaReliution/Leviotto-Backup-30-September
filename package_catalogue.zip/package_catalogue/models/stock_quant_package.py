# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo import models, fields, api, _, tools


class QuantPackage(models.Model):
    _inherit = "stock.quant.package"

    categ_id = fields.Many2one(
        comodel_name='product.category',
        string="Product Category", compute="_compute_categ_id", store=True
    )

    product_template_attribute_value_ids = fields.Many2many('product.template.attribute.value',
                                                            string="Attribute Values", ondelete='restrict',
                                                            compute="_compute_product_attribute_values", store=True
                                                             )

    @api.depends('quant_ids','quant_ids.product_id','quant_ids.product_id.product_template_attribute_value_ids')
    def _compute_product_attribute_values(self):
        for package in self:
            attribute_values = set()
            for quant in package.quant_ids:
                for attribute_value in quant.product_id.mapped('product_template_attribute_value_ids'):
                    attribute_values.add(attribute_value.id)
            package.product_template_attribute_value_ids = [(6, 0, list(attribute_values))]

    @api.depends('quant_ids','quant_ids.product_id','quant_ids.product_id.categ_id')
    def _compute_categ_id(self):
        for package in self:
            product_tmpl_ids = package.quant_ids.mapped('product_id.product_tmpl_id')
            if product_tmpl_ids:
                package.categ_id = product_tmpl_ids[0].categ_id.id