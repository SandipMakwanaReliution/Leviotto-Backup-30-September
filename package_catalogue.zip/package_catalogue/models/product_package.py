# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import _, models


class ProductPackage(models.AbstractModel):
    _name = 'product.package'
    _description = 'Product Package'

    def action_add_from_package(self):
        kanban_view_id = self.env.ref('package_catalogue.product_package_view_kanban').id
        search_view_id = self.env.ref('package_catalogue.product_package_search_view').id
        additional_context = self._get_action_add_from_package_extra_context()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Packages'),
            'res_model': 'stock.quant.package',
            'views': [(kanban_view_id, 'kanban'), (False, 'form')],
            'search_view_id': [search_view_id, 'search'],
            'domain': self._get_product_package_domain(),
            'context': {**self.env.context, **additional_context},
        }

    def _get_action_add_from_package_extra_context(self):
        return {
            'product_package_order_id': self.id,
            'product_package_order_model': self._name,
            'product_package_currency_id': self.currency_id.id,
            'product_package_digits': self.order_line._fields['price_unit'].get_digits(self.env),
        }

    def _get_product_package_domain(self):
        return [
            ('company_id', 'in', [self.company_id.id, False]),
            ('location_id', '!=', False),
            ('location_id.usage', '!=', 'customer'),
            ('location_id', 'child_of' , [
                self.env.ref('stock.stock_location_stock').id,
                self.env.ref('stock.stock_location_output').id
            ]),
        ]

    def _get_product_package_order_line_info(self, package_ids, **kwargs):
        order_line_info = {}
        default_data = self._default_package_order_line_values()
        package_line_data = {}
        for package, record_lines in self._get_product_package_record_lines(package_ids).items():
            data = self.env['sale.order.line']._get_product_package_lines_data(record_lines, **kwargs)
            if 'quantity' in data:
                order_line_info[package.id] = data
            order_line_info.update(package_line_data)
            if package:
                package_ids.remove(package.id)
        packages = self.env['stock.quant.package'].browse(package_ids)
        package_data = self._get_product_package_order_data(packages, **kwargs)
        for package_id, data in package_data.items():
            order_line_info[package_id] = {**default_data, **data}
        return order_line_info

    def _default_package_order_line_values(self):
        return {
            'quantity': 0,
            'readOnly': self._is_readonly() if self else False,
        }

    def _get_product_package_order_data(self, packages, **kwargs):
        res = {}
        for package in packages:
            total_qty = 0
            package_qty = 0
            product_tmpl_ids = package.quant_ids.mapped('product_id.product_tmpl_id')
            if product_tmpl_ids:
                product_name = product_tmpl_ids[0].name
            for quant_id in package.quant_ids:
                total_qty += quant_id.product_id.qty_available
            package_qty += sum(package.quant_ids.mapped('quantity'))
            res[package.id] = {
                'packageName': package.name,
                'packageId': package.id,
                'productQty': total_qty,
                'price': quant_id.product_id.lst_price,
                'productName': product_name,
                'packageQty': package_qty
            }
        return res
