# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from collections import defaultdict
from odoo import models, fields, api, _

from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _name = 'sale.order'
    _inherit = ['sale.order', 'product.package']

    def _get_product_package_record_lines(self, package_ids):
        package_ids = self.env['stock.quant.package'].browse(package_ids)
        grouped_lines = defaultdict(lambda: self.env['sale.order.line'])
        product_ids = []
        for package_id in package_ids:
            for quant_id in package_id.quant_ids:
                product_ids.append(quant_id.product_id.id)
        for line in self.order_line:
            if line.display_type or line.product_id.id not in product_ids:
                continue
            grouped_lines[line.package_id] |= line
        return grouped_lines

    def _update_package_order_line_info(self, package, quantity, **kwargs):
        package_id = self.env['stock.quant.package'].browse(package)
        for quant_id in package_id.quant_ids:
            sol = self.order_line.filtered(
                lambda line: line.product_id.id == quant_id.product_id.id and line.package_id == package_id)
            if sol:
                if quantity != 0:
                    sol.product_uom_qty = quant_id.quantity * quantity
                    sol.package_qty = quantity
                elif self.state in ['draft', 'sent']:
                    sol.unlink()
                else:
                    sol.product_uom_qty = 0
            elif quantity > 0:
                self.env['sale.order.line'].create({
                    'order_id': self.id,
                    'product_id': quant_id.product_id.id,
                    'product_uom_qty': quant_id.quantity * quantity,
                    'sequence': ((self.order_line and self.order_line[-1].sequence + 1) or 10),
                    'package_id': package_id.id,
                    'package_qty': quantity
                })


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    package_id = fields.Many2one('stock.quant.package', string='Package')
    package_qty = fields.Float()

    def action_add_from_package(self):
        order = self.env['sale.order'].browse(self.env.context.get('order_id'))
        if order.state == 'sale':
            raise ValidationError(_('You are not allow to make changes in confirm order.'))
        else:
            return order.action_add_from_package()

    def _get_product_package_lines_data(self, record_lines, **kwargs):
        for record_line in record_lines:
            total_qty = 0
            package_qty = 0
            product_tmpl_ids = record_line.package_id.quant_ids.mapped('product_id.product_tmpl_id')
            product_name = ''
            if product_tmpl_ids:
                product_name = product_tmpl_ids[0].name
            for quant_id in record_line.package_id.quant_ids:
                total_qty += quant_id.product_id.qty_available
            package_qty += sum(record_line.package_id.quant_ids.mapped('quantity'))
            res = {
                'quantity': record_line.package_qty,
                'readOnly': record_line.order_id._is_readonly() or (record_line.product_id.sale_line_warn == "block"),
                'packageName': record_line.package_id.name,
                'packageId': record_line.package_id.id,
                'productQty': total_qty,
                'price': record_line.price_unit,
                'productName': product_name,
                'packageQty': package_qty
            }
            return res
