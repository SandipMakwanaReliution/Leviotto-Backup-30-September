# -*- coding: utf-8 -*-

{
    'name': 'Profit & Loss Report',
    'version': '17.0.0.1',
    'summary': '',
    'sequence': 0,
    'author': "Reliution",
    'license': 'OPL-1',
    'description': """""",
    'depends': [
        'account',
        'shop_customization',
    ],
    'data': [
        'security/ir.model.access.csv',
        'report/accounting_reports.xml',
        'report/accounting_reports_templates.xml',
        'wizard/accounting_reports_wizard_views.xml',
        'wizard/shop_acc_reports_wizard_views.xml',
        'report/shop_acc_reports_templates.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
