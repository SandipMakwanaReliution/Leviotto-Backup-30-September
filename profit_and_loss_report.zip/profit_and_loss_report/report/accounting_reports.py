# -*- coding: utf-8 -*-

from odoo import models


class ReportProfitAndLoss(models.AbstractModel):
    _name = 'report.profit_and_loss_report.accounting_reports_profit_and_loss'
    _description = 'Report Profit And Loss'
    _table = 'invoice_customization_pnl'

    def _get_report_values(self, docids, data=None):
        docs = self.env['accounting.reports.wizard'].with_context(custom_report_email=True).browse(docids)
        data.update({
            'docs': docs,
        })
        return data
