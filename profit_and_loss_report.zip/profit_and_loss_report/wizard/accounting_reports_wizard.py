# -*- coding: utf-8 -*-

import base64
import logging
from dateutil.relativedelta import relativedelta
from odoo import fields, models

_logger = logging.getLogger(__name__)


class AccountingReportsWizard(models.TransientModel):
    _name = 'accounting.reports.wizard'
    _description = 'Accounting Reports Wizard'

    date_from = fields.Date('Date From', default=fields.Date.today() + relativedelta(day=1))
    date_to = fields.Date('Date To', default=fields.Date.today())
    data = fields.Binary('File', readonly=True, attachment=False)
    filename = fields.Char(string='Filename', size=256, readonly=True)
    report_type = fields.Selection([('view', 'View'), ('download', 'Download')], string='Report Type', default='view')

    def get_balance(self, line_type=None, opening=False):
        company = self.env.companies
        date_from = self.date_from.strftime('%Y-%m-%d')
        date_to = self.date_to.strftime('%Y-%m-%d')
        purchase_accounts = self.env['account.journal'].search([('company_id', 'in', company.ids), ('type', '=', 'purchase')]).default_account_id
        valuation_account_id = []
        for com in company:
            valuation_account_id.append(self.env['product.category'].search([], order='id desc', limit=1).with_company(com).property_stock_valuation_account_id.id)
        extra_join = ''
        where_clause = "WHERE aml.date >= %s AND aml.date <= %s AND ac.id IN %s AND aml.parent_state = 'posted'"
        if line_type == 'sale':
            accounts = self.env['account.journal'].search([('company_id', 'in', company.ids), ('type', '=', 'sale')]).default_account_id.ids
        elif line_type == 'purchase':
            accounts = purchase_accounts.ids
            extra_join = """
                JOIN account_move am ON aml.move_id = am.id
            """
            where_clause += "AND am.move_type IN ('in_invoice', 'in_refund')"
        elif line_type == 'cogs_sold':
            self.env.cr.execute("""
                SELECT
                   COALESCE(SUM(CASE WHEN aml.credit > 0.0 THEN aml.credit ELSE (aml.debit * -1) END), 0.0) AS balance
                  FROM account_move_line aml
                  JOIN account_move am ON aml.move_id = am.id
                  JOIN stock_move sm ON am.stock_move_id = sm.id
                  JOIN stock_picking sp ON sm.picking_id = sp.id
                  JOIN account_move_stock_picking_rel rel ON sp.id = rel.stock_picking_id
                  JOIN account_move inv ON rel.account_move_id = inv.id
                 WHERE sm.state = 'done'
                 AND inv.move_type IN ('out_invoice', 'out_refund')
                 AND aml.date >= %s
                 AND aml.date <= %s
                 AND aml.account_id = %s
            """, (date_from, date_to, valuation_account_id))
            res = self.env.cr.dictfetchall()
            return res
        elif line_type == 'cogs':
            where_clause = "WHERE account_id IN %s AND parent_state = 'posted' AND date <= %s"
            params = (tuple(valuation_account_id), date_to)
            if opening:
                where_clause = "WHERE account_id IN %s AND parent_state = 'posted' AND date < %s"
                params = (tuple(valuation_account_id), date_from)
            sql = """
                SELECT
                   COALESCE(SUM(CASE WHEN debit > 0.0 THEN debit ELSE (credit * -1) END), 0.0) AS balance
                  FROM account_move_line
                 """ + where_clause
            self.env.cr.execute(sql, params)
            res = self.env.cr.dictfetchall()
            return res
        elif line_type == 'expense':
            accounts = (self.env['account.account'].search([('company_id', 'in', company.ids), ('internal_group', '=', 'expense')]) - purchase_accounts).ids
        sql = """
            SELECT
               ac.name,
               ABS(SUM(aml.debit - aml.credit)) AS balance
              FROM account_move_line aml
              JOIN account_account ac ON aml.account_id = ac.id
             """ + extra_join + where_clause + """
            GROUP BY ac.id
        """
        self.env.cr.execute(sql, (date_from, date_to, tuple(accounts)))
        res = self.env.cr.dictfetchall()
        return res

    def calculate_percentage(self, amount, base_amount):
        print(amount, '===============b', base_amount)
        return (amount * 100) / (base_amount or 1.0)

    def print_report(self):
        company = self.env.companies
        lang = self.env.user.lang
        sale_lines = []
        cogs_lines = []
        expense_lines = []
        net_profit = []
        lines = []
        sale = self.get_balance(line_type='sale') or [{'name': 'Sales', 'balance': 0.0}]
        purchase = self.get_balance(line_type='purchase') or [{'name': 'Purchase', 'balance': 0.0}]
        cogs_closing = self.get_balance(line_type='cogs')
        cogs_opening = self.get_balance(line_type='cogs', opening=True)
        # cogs_sold = self.get_balance(line_type='cogs_sold')
        expenses = self.get_balance(line_type='expense') or [{'name': 'Expense', 'balance': 0.0}]
        income_amount = sale[0]['balance'] - (cogs_opening[0]['balance'] + purchase[0]['balance'] - cogs_closing[0]['balance'])
        expense_amount = sum([expense['balance'] for expense in expenses]) or 0.0
        sale[0].update({'level': 2, 'cal_percent': True})
        if type(sale[0]['name']) == dict:
            if sale[0]['name'].get(lang):
                sale[0]['name'] = sale[0]['name'][lang]

        purchase[0]['name'] = 'Purchase'
        purchase[0].update({'level': 2, 'cal_percent': True})
        cogs_closing[0].update({'name': 'Closing Stock', 'level': 1, 'cal_percent': False})
        cogs_opening[0].update({'name': 'Opening Stock', 'level': 1, 'cal_percent': False})
        # cogs_sold[0].update({'name': 'Cost of Goods Sold', 'level': 2, 'cal_percent': True})
        expenses[0].update({'level': 2, 'cal_percent': True})
        lines.append({'name': 'Income', 'balance': income_amount, 'level': 0, 'cal_percent': True})
        lines.append(sale[0])
        lines.append(cogs_closing[0])
        lines.append(cogs_opening[0])
        # lines.append(cogs_sold[0])
        lines.append(purchase[0])
        lines.append({'name': 'Expenses', 'balance': expense_amount, 'level': 0, 'cal_percent': True})
        sale_lines.append(sale[0])
        sale_lines.append(cogs_closing[0])
        cogs_lines.append(cogs_opening[0])
        cogs_lines.append(purchase[0])
        expense_lines.append({'name': 'Expenses', 'balance': expense_amount, 'level': 0, 'cal_percent': True})
        for expense in expenses:
            expense.update({'level': 2, 'cal_percent': True})
            if type(expense['name']) == dict:
                if expense['name'].get(lang):
                    expense.update({
                        'name': expense['name'][lang]
                    })
            lines.append(expense)
        lines.append({'name': 'Net Profit', 'balance': (income_amount - expense_amount), 'level': 0, 'cal_percent': True})

        #Added
        for expense in expenses:
            expense.update({'level': 2, 'cal_percent': True})
            expense_lines.append(expense)
        net_profit.append({'name': 'Net Profit', 'balance': (income_amount - expense_amount), 'level': 0, 'cal_percent': True})
        for line in lines:
            if line['cal_percent'] == True:
                line['percent'] = self.calculate_percentage(line['balance'], sale[0]['balance'])
        for line in expense_lines:
            if line['cal_percent'] == True:
                line['percent'] = self.calculate_percentage(line['balance'], sale[0]['balance'])
        data = {
            'company_name': company.mapped('name'),
            'lines': lines,
            'sale_lines': sale_lines,
            'cogs_lines': cogs_lines,
            'expense_lines': expense_lines,
            'net_profit': net_profit,
            'lang': str(lang)
        }
        value = self.env['ir.actions.report']._render_qweb_pdf('profit_and_loss_report.action_accounting_reports_profit_and_loss', self.id, data=data)[0]
        self.write({
            'data': base64.encodebytes(value),
            'filename': 'profit_and_loss_{date}.pdf'.format(date=fields.Date.today().strftime('%d_%m_%Y'))
        })

        if self.report_type == 'view':
            return {
                'name': 'Profit and Loss',
                'type': 'ir.actions.act_url',
                'url': "web/content/?model=accounting.reports.wizard&id=" + str(self.id) + "&filename_field=filename&field=data&filename=" + self.filename,
                'target': 'current',
            }
        else:
            return {
                'name': 'Profit and Loss',
                'type': 'ir.actions.act_url',
                'url': "web/content/?model=accounting.reports.wizard&id=" + str(self.id) + "&filename_field=filename&field=data&download=true&filename=" + self.filename,
                'target': 'self',
            }
