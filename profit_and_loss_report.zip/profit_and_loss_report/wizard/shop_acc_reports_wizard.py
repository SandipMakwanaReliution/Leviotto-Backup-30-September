# -*- coding: utf-8 -*-

import base64
import logging
from dateutil.relativedelta import relativedelta
from odoo import fields, models

_logger = logging.getLogger(__name__)


class ShopAccountingReportsWizard(models.TransientModel):
    _name = 'shop.accounting.reports.wizard'
    _description = 'Shop Accounting Reports Wizard'

    date_from = fields.Date(string='Date From', default=fields.Date.today() + relativedelta(day=1))
    date_to = fields.Date(string='Date To', default=fields.Date.today())
    data = fields.Binary(string='File', readonly=True, attachment=False)
    filename = fields.Char(string='Filename', size=256, readonly=True)
    report_type = fields.Selection(selection=[('view', 'View'), ('download', 'Download')],
                                   string='Report Type', default='view')
    shop_id = fields.Many2one(comodel_name='shop.shop', string='Shop')


    def get_balance(self, line_type=None):
        company = self.env.companies
        date_from = self.date_from.strftime('%Y-%m-%d')
        date_to = self.date_to.strftime('%Y-%m-%d')
        params = [date_from, date_to]
        purchase_accounts = self.env['account.journal'].search(
            [('company_id', 'in', company.ids), ('type', '=', 'purchase')]).default_account_id
        where_clause = "WHERE aml.date >= %s AND aml.date <= %s AND ac.id IN %s AND aml.parent_state = 'posted'"
        if line_type == 'sale':
            accounts = self.env['account.journal'].search([
                ('company_id', 'in', company.ids), ('type', '=', 'sale')]).default_account_id.ids
            params.append(tuple(accounts))
            if self.shop_id:
                where_clause += " AND aml.shop_id = %s "
                params.append(self.shop_id.id)
        elif line_type == 'total_sale':
            accounts = self.env['account.journal'].search([
                ('company_id', 'in', company.ids), ('type', '=', 'sale')]).default_account_id.ids
            params.append(tuple(accounts))
        elif line_type == 'sale_line_cost':
            sql = """
                SELECT SUM(sol.product_uom_qty * sol.purchase_price) AS balance
                FROM sale_order_line sol JOIN sale_order so 
                ON sol.order_id = so.id
                WHERE DATE(so.date_order) >= %s
                AND DATE(so.date_order) <= %s
                AND so.state IN ('sale')
            """
            params = [date_from, date_to]
            if self.shop_id:
                sql += " AND so.shop_id = %s"
                params.append(self.shop_id.id)
            self.env.cr.execute(sql, tuple(params))
            res = self.env.cr.dictfetchall()
            return res
        elif line_type == 'expense':
            accounts = (self.env['account.account'].search([
                ('company_id', 'in', company.ids), ('internal_group', '=', 'expense')]) - purchase_accounts).ids
            params.append(tuple(accounts))
            if self.shop_id:
                where_clause += " AND aml.shop_id = %s "
                params.append(self.shop_id.id)
            where_clause += "AND aml.is_shared_expense = False"
        elif line_type == 'total_shared_expense':
            accounts = (self.env['account.account'].search([
                ('company_id', 'in', company.ids), ('internal_group', '=', 'expense')]) - purchase_accounts).ids
            params.append(tuple(accounts))
            where_clause += " AND aml.is_shared_expense = TRUE "

        sql = """
            SELECT ac.name, ABS(SUM(aml.debit - aml.credit)) AS balance
            FROM account_move_line aml JOIN account_account ac 
            ON aml.account_id = ac.id
             """ + where_clause + """
            GROUP BY ac.id
        """
        self.env.cr.execute(sql, tuple(params))
        res = self.env.cr.dictfetchall()
        return res

    def calculate_percentage(self, amount, base_amount):
        return (amount * 100) / (base_amount or 1.0)

    def print_report(self):
        company = self.env.companies
        lang = self.env.user.lang

        sale_lines = []
        sale = self.get_balance(line_type='sale') or [{'name': 'Sales', 'balance': 0.0}]
        sale[0].update({'level': 2, 'cal_percent': True})
        sale_lines.append(sale[0])
        if type(sale[0]['name']) == dict:
            if sale[0]['name'].get(lang):
                sale[0]['name'] = sale[0]['name'][lang]
        for line in sale_lines:
            if line['cal_percent']:
                line['percent'] = self.calculate_percentage(line['balance'], sale[0]['balance'])

        sale_line_cost = []
        sale_line = self.get_balance(line_type='sale_line_cost')
        if not sale_line[0]['balance']:
            sale_line = [{'balance': 0.0}]
        sale_line[0].update({'level': 2, 'cal_percent': True})
        sale_line_cost.append(sale_line[0])
        for line in sale_line_cost:
            if line['cal_percent']:
                line['percent'] = self.calculate_percentage(line['balance'], sale[0]['balance'])

        expense_lines = []
        expenses = self.get_balance(line_type='expense') or [{'name': 'Expense', 'balance': 0.0}]
        # Expenses
        expense_amount = sum([expense['balance'] for expense in expenses]) or 0.0
        expense_lines.append({'name': 'Expenses', 'balance': expense_amount, 'level': 0, 'cal_percent': True})
        # Expense Lines
        for expense in expenses:
            expense.update({'level': 2, 'cal_percent': True})
            if type(expense['name']) == dict:
                if expense['name'].get(lang):
                    expense.update({
                        'name': expense['name'][lang]
                    })
            expense_lines.append(expense)
        for line in expense_lines:
            if line['cal_percent']:
                line['percent'] = self.calculate_percentage(line['balance'], sale[0]['balance'])

        total_shared_expense = self.get_balance(line_type='total_shared_expense') or [{'balance': 0.0}]
        total_sale = self.get_balance(line_type='total_sale') or [{'balance': 0.0}]
        shop_expense = {}
        if self.shop_id:
            if sale_lines[0]['balance']:
                shop_per = (sale_lines[0]['balance'] / total_sale[0].get('balance')) * 100
                shop_expense['balance'] = (total_shared_expense[0].get('balance') * shop_per) / 100
                if shop_expense['balance']:
                    shop_expense['percent'] = shop_per
                else:
                    shop_expense['percent'] = 0.0
            else:
                shop_expense['balance'] = 0.0
                shop_expense['percent'] = 0.0
        else:
            shop_expense['balance'] = total_shared_expense[0].get('balance')
            shop_expense['percent'] = self.calculate_percentage(
                total_shared_expense[0]['balance'], total_shared_expense[0]['balance'])

        data = {
            'company_name': company.mapped('name'),
            'lang': str(lang),
            'sale_lines': sale_lines,
            'sale_line_cost' : sale_line_cost,
            'expense_lines': expense_lines,
            'shop_expense': shop_expense,
            'shop_name': self.shop_id.name if self.shop_id else False,
        }
        value = self.env['ir.actions.report']._render_qweb_pdf('profit_and_loss_report.action_shop_accounting_reports_profit_and_loss', self.id, data=data)[0]
        self.write({
            'data': base64.encodebytes(value),
            'filename': f"profit_and_loss_{fields.Date.today():%d_%m_%Y}.pdf"
        })
        if self.report_type == 'view':
            return {
                'name': 'Profit and Loss',
                'type': 'ir.actions.act_url',
                'url': "web/content/?model=shop.accounting.reports.wizard&id=" + str(
                    self.id) + "&filename_field=filename&field=data&filename=" + self.filename,
                'target': 'current',
            }
        else:
            return {
                'name': 'Profit and Loss',
                'type': 'ir.actions.act_url',
                'url': "web/content/?model=shop.accounting.reports.wizard&id=" + str(
                    self.id) + "&filename_field=filename&field=data&download=true&filename=" + self.filename,
                'target': 'self',
            }